# -*- coding: utf-8 -*-
"""
Created on Sat Jun  1 00:12:52 2019

@author: beau
"""
# this script may be totally useless to you. look in the extResources folder
# at the tk_img2video.py code and follow the link i included. it's what
# makes the videos from the images



# for making and moving/copying to a new output folder for the pics and video 
import os
import shutil

# used to generate data for the plots
import numpy as np

# creates plots of data with no gui popups because .use('Agg') 
# and saves the files to images
import matplotlib
matplotlib.use('Agg')    # comment out this line to show plots
import matplotlib.pyplot as plt

# for testing purposes
import time



class FrameGenerator():
    
    def __init__(self, name, imgExtension, frameRate, videoDuration):    # (seconds, fps)
        self.name = name
        self.imgExtension = imgExtension
        self.frameRate = frameRate
        self.videoDuration = videoDuration
        self.totalFrames = frameRate * videoDuration


    def setOutputFolder(self, path):
        
        self.outPath = path
    
        try: os.mkdir(self.outPath)   # will throw exception if fails to create
        except FileExistsError:  
            print('\nDirectory %s already exists' % self.outPath)
        except:
            print('\nuh oh, something went wrong...')
        else:  
            print('\nSuccessfully created the directory %s ' % self.outPath)
    
    
    def getOutputFolder(self):
        try: self.outPath
        except AttributeError: self.outPath = os.getcwd() 
        return self.outPath
    
     
    def generateImages(self):
        print('\nPlease wait while your images are generated')
        print('This may take a while...\n')

        startTime = time.time()
        
        for f in range(self.totalFrames + 1):
            if f is not 0:    # fixes issues with plot range
#                fig = plt.figure()    # if you hide close below, hide this too
                
                plt.axis([0,1,0,1])
                
                x = np.random.random()
                y = np.random.random()
                        
                plt.scatter(x,y)
                plt.pause(0.001)    # lower is faster; dont enter 0
                
                # change number in braces for more digits in file name
                fileName  = 'img'+ '{:05}'.format(f) + '.' + self.imgExtension
                
                plt.savefig(self.getOutputFolder() + '\\' + fileName)
#                plt.close(fig)    # uncomment to refresh plot each time
                    
        runTime = time.time() - startTime
        
        print('\nImage generation completed in ' + str(runTime) + ' seconds\n')
             
        
        
def makeVideo(inst):    # iono why i did it this dumb way 
    wd = os.getcwd()
    script = 'new_tk_img2video.py'
    extension = inst.imgExtension
    name = inst.name + '.avi'
    path = inst.getOutputFolder()
    frameRate = str(inst.frameRate)
    
#    print(wd)
#    print(script)
#    print(f'{wd}\{script}')
#    print(extension)
#    print(name)
#    print(path)
#    print(frameRate)
    
    # clunky and bad bad bad way to call other scripts
    shutil.copy(wd + '\\extResources\\' + script, wd)
    os.system(f'python {wd}\{script} -c {extension} -o {name} -d {path} -fps {frameRate}')
    os.remove(f'{script}')  
    
    # i fucked with this damn function for so long i wanted to crush my computer
    # then i realized the os call to python wasn't calling python. pretty sure 
    # it's cuz python isn't in the %path% Environment Variable. might work
    # in linux
    
  
    
def main():
    outFldr = 'ootpoot'
    outpath = os.path.join(os.getcwd(), outFldr)
    
    # multiply arguements to determine number of images this will create
    randPlot = FrameGenerator('randPlot', 'png', 1, 30)    # (name, seconds, fps)
    randPlot.setOutputFolder(outpath)    
    randPlot.generateImages()
        
    makeVideo(randPlot)
  
    
    
main()